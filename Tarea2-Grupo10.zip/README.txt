Integrantes:
Jorge Ignacio Contreras Cabrera		201573547-6
Juan Pablo Jorquera Zapata		201573533-6

La tarea fue hecha usando Mysql (el archivo exportado fue creado con Mysql Workbench).

Algunas de las modificaciones o supuestos son:
- Los asientos no son enumerados, por lo que solo se verifica la cantidad de asientos disponibles.
- Los empleados pueden comentar las películas, pero se les añade [E] al lado del usuario para identificarlos.
- Al ser incluir participantes en modificar película, añadimos sólo la opción de agregar actores y/o directores.
- Como la gestión de turnos no especifica día del mes o año, se asumió como relevante sólo el día de la semana.


Para el trabajo se crearon dos cines, donde los usuarios de cada uno son:
- Cine 1:	eparedes : proyectador
		jvillar : vendedor
- Cine 2:	cbaeza : proyectador
		valdés : vendedor

También se crearon dos usuarios para clientes:
- bstinson
- tmosby

Para facilitar el acceso, la contraseña de todos ellos es 1234.